java -cp lib\mj-runtime.jar rs.etf.pp1.mj.runtime.Run test/test1.obj -debug
Write-Output "--------------------------------------------------------------"
Write-Output "--------------------------------------------------------------"
Write-Output "--------------------------------------------------------------"
java -cp lib\mj-runtime.jar rs.etf.pp1.mj.runtime.Run test/test2.obj -debug
Write-Output "--------------------------------------------------------------"
Write-Output "--------------------------------------------------------------"
Write-Output "--------------------------------------------------------------"
java -cp lib\mj-runtime.jar rs.etf.pp1.mj.runtime.Run test/test3.obj -debug
Write-Output "--------------------------------------------------------------"
Write-Output "--------------------------------------------------------------"
Write-Output "--------------------------------------------------------------"
java -cp lib\mj-runtime.jar rs.etf.pp1.mj.runtime.Run test/test4.obj -debug
Write-Output "--------------------------------------------------------------"
Write-Output "--------------------------------------------------------------"
Write-Output "--------------------------------------------------------------"
java -cp lib\mj-runtime.jar rs.etf.pp1.mj.runtime.Run test/test5.obj -debug
Write-Output "--------------------------------------------------------------"
Write-Output "--------------------------------------------------------------"
Write-Output "--------------------------------------------------------------"
java -cp lib\mj-runtime.jar rs.etf.pp1.mj.runtime.Run test/test6.obj -debug
Write-Output "--------------------------------------------------------------"
Write-Output "--------------------------------------------------------------"
Write-Output "--------------------------------------------------------------"
java -cp lib\mj-runtime.jar rs.etf.pp1.mj.runtime.Run test/test7.obj -debug
Write-Output "--------------------------------------------------------------"
Write-Output "--------------------------------------------------------------"
Write-Output "--------------------------------------------------------------"
java -cp lib\mj-runtime.jar rs.etf.pp1.mj.runtime.Run test/test9.obj -debug
Write-Output "--------------------------------------------------------------"
Write-Output "--------------------------------------------------------------"
Write-Output "--------------------------------------------------------------"
java -cp lib\mj-runtime.jar rs.etf.pp1.mj.runtime.Run test/test10.obj -debug
Write-Output "--------------------------------------------------------------"
Write-Output "--------------------------------------------------------------"
Write-Output "--------------------------------------------------------------"
java -cp lib\mj-runtime.jar rs.etf.pp1.mj.runtime.Run test/test11.obj -debug
Write-Output "--------------------------------------------------------------"
Write-Output "--------------------------------------------------------------"
Write-Output "--------------------------------------------------------------"
java -cp lib\mj-runtime.jar rs.etf.pp1.mj.runtime.Run test/test12.obj -debug
Write-Output "--------------------------------------------------------------"
Write-Output "--------------------------------------------------------------"
Write-Output "--------------------------------------------------------------"
java -cp lib\mj-runtime.jar rs.etf.pp1.mj.runtime.Run test/test13.obj -debug
Write-Output "--------------------------------------------------------------"
Write-Output "--------------------------------------------------------------"
Write-Output "--------------------------------------------------------------"
java -cp lib\mj-runtime.jar rs.etf.pp1.mj.runtime.Run test/test14.obj -debug
Write-Output "--------------------------------------------------------------"
Write-Output "--------------------------------------------------------------"
Write-Output "--------------------------------------------------------------"
java -cp lib\mj-runtime.jar rs.etf.pp1.mj.runtime.Run test/test15.obj -debug
Write-Output "--------------------------------------------------------------"
Write-Output "--------------------------------------------------------------"
Write-Output "--------------------------------------------------------------"
java -cp lib\mj-runtime.jar rs.etf.pp1.mj.runtime.Run test/test16.obj -debug
Write-Output "--------------------------------------------------------------"
Write-Output "--------------------------------------------------------------"
Write-Output "--------------------------------------------------------------"
java -cp lib\mj-runtime.jar rs.etf.pp1.mj.runtime.Run test/test17.obj -debug
Write-Output "--------------------------------------------------------------"
Write-Output "--------------------------------------------------------------"
Write-Output "--------------------------------------------------------------"
java -cp lib\mj-runtime.jar rs.etf.pp1.mj.runtime.Run test/test18.obj -debug
Write-Output "--------------------------------------------------------------"
Write-Output "--------------------------------------------------------------"
Write-Output "--------------------------------------------------------------"
java -cp lib\mj-runtime.jar rs.etf.pp1.mj.runtime.Run test/test19.obj -debug
Write-Output "--------------------------------------------------------------"
Write-Output "--------------------------------------------------------------"
Write-Output "--------------------------------------------------------------"
java -cp lib\mj-runtime.jar rs.etf.pp1.mj.runtime.Run test/test20.obj -debug
Write-Output "--------------------------------------------------------------"
Write-Output "--------------------------------------------------------------"
Write-Output "--------------------------------------------------------------"
java -cp lib\mj-runtime.jar rs.etf.pp1.mj.runtime.Run test/test21.obj -debug
Write-Output "--------------------------------------------------------------"
Write-Output "--------------------------------------------------------------"
Write-Output "--------------------------------------------------------------"
java -cp lib\mj-runtime.jar rs.etf.pp1.mj.runtime.Run test/test22.obj -debug
Write-Output "--------------------------------------------------------------"
Write-Output "--------------------------------------------------------------"
Write-Output "--------------------------------------------------------------"
java -cp lib\mj-runtime.jar rs.etf.pp1.mj.runtime.Run test/test23.obj -debug
Write-Output "--------------------------------------------------------------"
Write-Output "--------------------------------------------------------------"
Write-Output "--------------------------------------------------------------"
java -cp lib\mj-runtime.jar rs.etf.pp1.mj.runtime.Run test/test24.obj -debug
Write-Output "--------------------------------------------------------------"
Write-Output "--------------------------------------------------------------"
Write-Output "--------------------------------------------------------------"
java -cp lib\mj-runtime.jar rs.etf.pp1.mj.runtime.Run test/test25.obj -debug
Write-Output "--------------------------------------------------------------"
Write-Output "--------------------------------------------------------------"
Write-Output "--------------------------------------------------------------"
java -cp lib\mj-runtime.jar rs.etf.pp1.mj.runtime.Run test/test26.obj -debug
Write-Output "--------------------------------------------------------------"
Write-Output "--------------------------------------------------------------"
Write-Output "--------------------------------------------------------------"
java -cp lib\mj-runtime.jar rs.etf.pp1.mj.runtime.Run test/test27.obj -debug
Write-Output "--------------------------------------------------------------"
Write-Output "--------------------------------------------------------------"
Write-Output "--------------------------------------------------------------"
Write-Host -NoNewLine 'Press any key to continue...';
$null = $Host.UI.RawUI.ReadKey('NoEcho,IncludeKeyDown');