// generated with ast extension for cup
// version 0.8
// 18/0/2021 20:18:34


package rs.ac.bg.etf.pp1.ast;

public class GotoStatement extends Statement {

    private String G1;
    private String identification;

    public GotoStatement (String G1, String identification) {
        this.G1=G1;
        this.identification=identification;
    }

    public String getG1() {
        return G1;
    }

    public void setG1(String G1) {
        this.G1=G1;
    }

    public String getIdentification() {
        return identification;
    }

    public void setIdentification(String identification) {
        this.identification=identification;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("GotoStatement(\n");

        buffer.append(" "+tab+G1);
        buffer.append("\n");

        buffer.append(" "+tab+identification);
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [GotoStatement]");
        return buffer.toString();
    }
}
